CREATE DATABASE "book-db";

CREATE TABLE public.book (
	id serial4 NOT NULL,
	"name" varchar(255) NOT NULL,
	category varchar(100) NOT NULL,
	publisher varchar(100) NOT NULL,
	CONSTRAINT book_pkey PRIMARY KEY (id)
);