package model

type Book struct {
	Id        uint   `json:"id" db:"id"`
	Name      string `json:"name" db:"name"`
	Category  string `json:"category" db:"category"`
	Publisher string `json:"publisher" db:"publisher"`
}
