package config

import (
	"context"
	"fmt"
	"os"

	pgxuuid "github.com/jackc/pgx-gofrs-uuid"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

const (
	db_password = "mysecretpassword"
	db_host     = "localhost"
	db_port     = "5432"
	db_user     = "postgres"
	db_name     = "book-db"
)

var (
	Db  *pgxpool.Pool
	err error
)

func LoadDatabase() {
	connStr := fmt.Sprintf(
		"postgres://%s:%s@%s:%s/%s", db_user, db_password, db_host, db_port, db_name,
	)
	dbconfig, _ := pgxpool.ParseConfig(connStr)
	dbconfig.AfterConnect = func(_ context.Context, conn *pgx.Conn) error {
		pgxuuid.Register(conn.TypeMap())
		return nil
	}
	Db, err = pgxpool.NewWithConfig(context.Background(), dbconfig)
	if err != nil {
		fmt.Fprintf(os.Stderr, "Unable to create connection pool: %v\n", err)
		os.Exit(1)
	}
}
