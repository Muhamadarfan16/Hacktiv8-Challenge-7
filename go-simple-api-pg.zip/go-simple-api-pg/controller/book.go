package controller

import (
	"go-simple-api/datasource"
	"go-simple-api/model"
	"go-simple-api/util"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

func GetAllBooks(c *gin.Context) {
	dataSource := datasource.BookDataSource{}
	res, err := dataSource.GetAllBooks()
	if err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}
	util.ResponseSuccess(c, res)
}

func GetBookById(c *gin.Context) {
	var err error
	dataSource := datasource.BookDataSource{}
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}
	book, err := dataSource.GetBookById(uint(id))
	if err != nil {
		util.ResponseError(c, http.StatusBadRequest, err.Error())
		return
	}
	util.ResponseSuccess(c, book)
}

func CreateBook(c *gin.Context) {
	var newBook model.Book

	if err := c.ShouldBindJSON(&newBook); err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}
	dataSource := datasource.BookDataSource{}
	err := dataSource.CreateBook(&newBook)
	if err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}
	util.ResponseSuccess(c, "success")
}

func UpdateBook(c *gin.Context) {
	var err error
	var newBook model.Book
	dataSource := datasource.BookDataSource{}
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}

	if err = c.ShouldBindJSON(&newBook); err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}
	newBook.Id = uint(id)
	err = dataSource.UpdateBook(&newBook)
	if err != nil {
		util.ResponseError(c, http.StatusBadRequest, err.Error())
		return
	}
	util.ResponseSuccess(c, "success")
}

func DeleteBook(c *gin.Context) {
	var err error
	dataSource := datasource.BookDataSource{}
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}

	err = dataSource.DeleteBook(uint(id))
	if err != nil {
		util.ResponseError(c, http.StatusBadRequest, err.Error())
		return
	}
	util.ResponseSuccess(c, "success")
}
