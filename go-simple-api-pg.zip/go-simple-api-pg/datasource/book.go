package datasource

import (
	"context"
	"errors"
	"fmt"
	"go-simple-api/config"
	"go-simple-api/model"
	"strconv"

	"github.com/jackc/pgx/v5"
)

type BookDataSource struct{}

func (d *BookDataSource) GetAllBooks() ([]model.Book, error) {
	rows, err := config.Db.Query(context.Background(), "select * from book")
	if err != nil {
		return []model.Book{}, err
	}
	return pgx.CollectRows(rows, pgx.RowToStructByName[model.Book])
}

func (d *BookDataSource) GetBookById(id uint) (model.Book, error) {
	rows, err := config.Db.Query(context.Background(), "select * from book where id = $1", id)
	if err != nil {
		return model.Book{}, err
	}
	return pgx.CollectOneRow(rows, pgx.RowToStructByName[model.Book])
}

func (d *BookDataSource) CreateBook(book *model.Book) error {
	sql := "INSERT INTO book(name, category, publisher) VALUES($1, $2, $3)"
	_, err := config.Db.Exec(context.Background(), sql, book.Name, book.Category, book.Publisher)
	if err != nil {
		return err
	}
	return nil
}

func (d *BookDataSource) UpdateBook(newBook *model.Book) error {
	sql := "UPDATE book SET name=$1, category=$2, publisher=$3 where id=$4"
	i, err := config.Db.Exec(context.Background(), sql, newBook.Name, newBook.Category, newBook.Publisher, newBook.Id)
	if err != nil {
		return err
	}
	if i.RowsAffected() == 0 {
		return errors.New(fmt.Sprintf("book with id %s not found", strconv.Itoa(int(newBook.Id))))
	}
	return nil
}

func (d *BookDataSource) DeleteBook(id uint) error {
	sql := "DELETE FROM book where id=$1"
	i, err := config.Db.Exec(context.Background(), sql, id)
	if err != nil {
		return err
	}
	if i.RowsAffected() == 0 {
		return errors.New(fmt.Sprintf("book with id %s not found", strconv.Itoa(int(id))))
	}
	return nil
}
