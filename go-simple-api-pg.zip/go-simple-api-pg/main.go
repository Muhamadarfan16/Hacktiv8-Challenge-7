package main

import (
	"go-simple-api/config"
	"go-simple-api/controller"
	"net/http"

	"github.com/gin-gonic/gin"
)

const (
	port = ":8080"
)

func main() {
	config.LoadDatabase()
	defer config.Db.Close()

	r := gin.Default()
	r.GET("/books", controller.GetAllBooks)
	r.GET("/book/:id", controller.GetBookById)
	r.POST("/book", controller.CreateBook)
	r.PATCH("/book/:id", controller.UpdateBook)
	r.DELETE("/book/:id", controller.DeleteBook)
	r.Run(port)
	http.ListenAndServe(port, nil)
}
