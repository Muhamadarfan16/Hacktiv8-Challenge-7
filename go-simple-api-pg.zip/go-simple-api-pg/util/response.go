package util

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func ResponseSuccess(c *gin.Context, data interface{}) {
	c.JSON(http.StatusOK, gin.H{
		"data": data,
	})
}

func ResponseError(c *gin.Context, errCode int, msg string) {
	c.AbortWithStatusJSON(errCode, gin.H{
		"error_code": errCode,
		"message":    msg,
	})
}
